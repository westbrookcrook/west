<?php

namespace Cysha\Casino\Holdem\Exceptions;

use Exception;

class PlayerException extends Exception
{
}
